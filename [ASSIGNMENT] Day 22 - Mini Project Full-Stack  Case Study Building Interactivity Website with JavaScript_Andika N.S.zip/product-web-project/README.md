# SimpleStore — Product Detail Assignment

Project pembelajaran web development menggunakan HTML, CSS, Vanilla JavaScript, Node.js/Express, API eksternal, dan SQL (SQLite).

## Fitur

- Halaman Product 1 menggunakan data hardcode di `frontend/js/products.js`.
- Halaman Product 2 mengambil data dari DummyJSON (`https://dummyjson.com/products/2`) melalui backend.
- Loading, error state, dan tombol retry untuk pengambilan data API.
- Kontrol jumlah produk, validasi input, dan kalkulasi subtotal.
- Pesanan dikirim ke backend dan disimpan ke database SQLite.
- Endpoint untuk melihat daftar pesanan.

## Persyaratan

- Node.js versi 18 atau lebih baru (disarankan versi LTS).
- npm.
- VS Code.

## Cara menjalankan di VS Code

1. Ekstrak ZIP project.
2. Buka folder `product-web-project` di VS Code.
3. Buka Terminal → New Terminal.
4. Install dependency:

   ```bash
   npm install
   ```

5. Jalankan server:

   ```bash
   npm start
   ```

6. Buka browser:

   - Product 1: http://localhost:3000/index.html
   - Product 2: http://localhost:3000/api.html
   - Status server: http://localhost:3000/api/health
   - Daftar pesanan: http://localhost:3000/api/orders

Jangan membuka file HTML langsung dengan `file://` atau hanya Live Server. Jalankan server Node.js supaya endpoint API dan database dapat digunakan.

## Struktur folder

```text
product-web-project/
├── backend/
│   ├── database/
│   │   └── schema.sql
│   ├── routes/
│   │   ├── orders.js
│   │   └── products.js
│   ├── db.js
│   └── server.js
├── frontend/
│   ├── css/style.css
│   ├── js/
│   │   ├── api.js
│   │   ├── app.js
│   │   ├── functions.js
│   │   └── products.js
│   ├── api.html
│   └── index.html
├── .gitignore
├── package.json
└── README.md
```

## SQL

Database SQLite dibuat otomatis pada `backend/database/shop.db` saat server pertama kali dijalankan. Struktur tabel ada di `backend/database/schema.sql`.

Tabel `orders` menyimpan pesanan. Tabel `api_logs` mencatat status pengambilan produk API.

## Pengujian yang perlu dilakukan

1. Buka halaman Product 1, pilih ukuran, jumlah 1, lalu pesan. Pastikan pesanan tersimpan.
2. Coba jumlah 0, angka negatif, desimal, dan jumlah di atas stok. Pastikan validasi muncul.
3. Buka halaman Product 2. Pastikan indikator loading tampil lalu data produk muncul.
4. Matikan koneksi internet sementara dan muat ulang Product 2. Pastikan pesan error tampil. Aktifkan internet lalu klik Coba Lagi.
5. Buka `http://localhost:3000/api/orders` untuk melihat pesanan yang tersimpan.

## Push ke GitHub

Buat repository baru di GitHub, lalu jalankan perintah berikut dari terminal pada folder project:

```bash
git init
git add .
git commit -m "Initial product detail project"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPOSITORY.git
git push -u origin main
```

Ganti URL remote dengan URL repository milik sendiri.

## Catatan penggunaan AI

AI digunakan sebagai asisten untuk membantu menyusun struktur project, memahami alur frontend-backend, memberi contoh integrasi API dan database, serta membantu meninjau potensi error. Seluruh kode tetap perlu dipahami, dijalankan, diuji, dan disesuaikan oleh student sebelum dikumpulkan.

## Catatan

Project ini adalah implementasi mandiri berdasarkan ringkasan assignment yang diberikan. Detail backend Practical 2 mungkin memiliki framework, pola arsitektur, atau skema SQL khusus dari instruktur. Sesuaikan jika panduan kelas mewajibkan hal tertentu.
