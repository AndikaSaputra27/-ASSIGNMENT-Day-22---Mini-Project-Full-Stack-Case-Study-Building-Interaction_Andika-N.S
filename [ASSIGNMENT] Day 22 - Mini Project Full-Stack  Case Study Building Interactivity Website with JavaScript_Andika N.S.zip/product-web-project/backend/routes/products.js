const express = require("express");
const router = express.Router();
const { db } = require("../db");

// Product 1 sengaja hardcode di frontend.
// Product 2 diambil dari API eksternal melalui backend.
router.get("/2", async (req, res) => {
  try {
    const response = await fetch("https://dummyjson.com/products/2");

    if (!response.ok) {
      return res.status(response.status).json({
        success: false,
        message: "API produk sedang tidak dapat diakses."
      });
    }

    const product = await response.json();

    if (!product || !product.id || !product.title || typeof product.price !== "number") {
      return res.status(502).json({
        success: false,
        message: "Format data dari API tidak sesuai."
      });
    }

    db.run(
      "INSERT INTO api_logs (endpoint, status) VALUES (?, ?)",
      ["/api/products/2", "success"],
      (error) => {
        if (error) console.error("Gagal menyimpan log API:", error.message);
      }
    );

    res.json({
      success: true,
      data: {
        id: product.id,
        title: product.title,
        description: product.description,
        price: product.price,
        discountPercentage: product.discountPercentage || 0,
        rating: product.rating || 0,
        stock: product.stock || 0,
        brand: product.brand || "Unknown",
        category: product.category || "Product",
        thumbnail: product.thumbnail,
        images: product.images || []
      }
    });
  } catch (error) {
    db.run(
      "INSERT INTO api_logs (endpoint, status) VALUES (?, ?)",
      ["/api/products/2", "error"],
      () => {}
    );

    res.status(500).json({
      success: false,
      message: "Tidak dapat mengambil data produk. Periksa koneksi internet.",
      detail: error.message
    });
  }
});

module.exports = router;